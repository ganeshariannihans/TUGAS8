<?php
class matakuliah_model extends CI_Model {
 public $nama;
 public $sks;
 public $kode; 
}
?>